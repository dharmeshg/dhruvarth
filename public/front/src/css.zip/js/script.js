// document.addEventListener('DOMContentLoaded', function() {
//     const headerTopSection = document.querySelector('.header-top-section');
//     const closeButton = document.querySelector('.close-welcome-text');

//     if (localStorage.getItem('headerClosed') === 'true') {
//         headerTopSection.classList.add('hide');
//     }

//     closeButton.addEventListener('click', function() {
//         headerTopSection.classList.add('hide');
//         localStorage.setItem('headerClosed', 'true');
//     });
// });

$('.banner-carousel, .testimonial-carousel').owlCarousel({
    nav:      false,
    navText:  false,
    margin:   0,
    loop:     true,
    autoplay: true,
    responsive:{
        0:{
                items:1
        },
        480:{
                items:1
        },
        768:{
                items:1
        }
    }
});


$(document).ready(function(){
    $('.shop-box-icon-carousel').owlCarousel({
        nav: true,
        margin: 10,
        navText: [
            '<img class="img-fluid" src="./src/images/slider-left-arrow.svg" width="auto" height="auto" alt="arrow"/>',
            '<img class="img-fluid" src="./src/images/slider-right-arrow.svg" width="auto" height="auto" alt="arrow"/>'
        ],
        loop: false,
        autoplay: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 3
            },
            375: {
                items: 3
            },
            600: {
                items: 3
            },
            1000: {
                items: 6
            }
        }
    });
});


$(document).ready(function(){
$('.product-logo-icon-carousel').owlCarousel({
    nav:      true,
    margin: 10,
    navText:  [ '<img class="img-fluid" src="./src/images/slider-left-arrow.svg" width="auto" height="auto" alt="arrow"/>', '<img class="img-fluid" src="./src/images/slider-right-arrow.svg" width="auto" height="auto" alt="arrow"/>' ],
    loop:     false,
    autoplay: true,
    responsiveClass: true,
    responsive:{
        0:{
                items:3
        },
        375: {
                items: 3
        },
        480:{
                items:3
        },
        768:{
                items:4
        }
    }
});
});

$(document).ready(function(){
$('.product-carousel').owlCarousel({
    nav: true,
        margin: 10,
        navText: [
            '<img class="img-fluid" src="./src/images/slider-left-arrow.svg" width="auto" height="auto" alt="arrow"/>',
            '<img class="img-fluid" src="./src/images/slider-right-arrow.svg" width="auto" height="auto" alt="arrow"/>'
        ],
        loop: false,
        autoplay: true,
        responsiveClass: true,
        responsive: {
            0: {
                items: 2
            },
            375: {
                items: 2
            },
            600: {
                items: 2
            },
            1000: {
                items: 4
            }
    }
});
});



window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}


$('.testimonial-carousel').owlCarousel({
        nav:      true,
        margin: 0,
        navText:  [ '<img class="img-fluid" src="./src/images/slider-left-arrow.svg" width="auto" height="auto" alt="arrow"/>', '<img class="img-fluid" src="./src/images/slider-right-arrow.svg" width="auto" height="auto" alt="arrow"/>' ],
        loop:     false,
        autoplay: true,
        responsive:{
            0:{
                    items:1
            },
            480:{
                    items:1
            },
            768:{
                    items:1
            }
        }
    });



    // Show or hide the back-to-top button
    $(window).scroll(function(){
        if ($(this).scrollTop() > 100) {
            $('#back-top').fadeIn();
        } else {
            $('#back-top').fadeOut();
        }
    });

    // Animate the scroll to top
    $('#back-top').click(function(){
        $('html, body').animate({scrollTop : 0}, 800);
        return false;
    });






    // document.addEventListener('DOMContentLoaded', function() {
    //     const headerTopSection = document.querySelector('.cookies-section');
    //     const closeButton = document.querySelector('.cookies-btn');
    
    //     if (localStorage.getItem('cookiesConsent') === 'true') {
    //         headerTopSection.classList.add('hide');
    //     }
    
    //     closeButton.addEventListener('click', function() {
    //         headerTopSection.classList.add('hide');
    //         localStorage.setItem('cookiesConsent', 'true');
    //     });
    // });


    // $('.navbar-toggler').on('click', function() {

    //     if ($('.mobile-header-menu').hasClass("show")) {
    
    //         $('.mobile-header-menu').removeClass('show');
    
    //         $('.open-icon').show();
    
    //         $('.close-icon').hide();
    
    //     } else {
    
    //         $('.mobile-header-menu').addClass('show');
    
    //         $('.open-icon').hide();
    
    //         $('.close-icon').show();
    
    //     }
    
    // });